import java.awt.*;

public class StartScreenState extends State {

    StartScreenState(Game game)
    {
        super(game);
    }

    /**
     * Updated every frame which will update any information and check to see
     * what needs to be changed based on the user input.
     */
    public void tick(){

    }

    /**
     * Updated every frame which will update any drawings and check to see
     * what needs to be changed based on the user input.
     * @param g - Graphics2D
     */
    public void render(Graphics g){

    }

}
