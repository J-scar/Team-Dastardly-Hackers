/**
 * The Launcher class holds the main method which is what makes a new Game object and begins the loop. Sets the width,
 * height and title of the game (Although currently, the window is not resizable.)
 *
 * @author Nathan Kloempken
 * @author Your names here
 * @author Another name here
 * @author final name
 *
 * @version 09/06/19 - Framework
 */
class Launcher {

    private static final int WINDOW_WIDTH = 1100;
    private static final int WINDOW_HEIGHT = 700;

    /**
     * The main method just makes and starts a new Game.
     * @param args - main
     */
    public static void main(String[] args){
        Game game = new Game("Hangman",WINDOW_WIDTH,WINDOW_HEIGHT);
        game.start();
    }

}
