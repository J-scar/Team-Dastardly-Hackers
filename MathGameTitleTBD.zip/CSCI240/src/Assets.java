/**
 * The Assets class stores all of the images and other assets that will be used by the game.
 */
abstract class Assets {

    //static final BufferedImage backgroundImage;

    //public static final backgroundMusic;

    static{
        //EXAMPLE:////backgroundImage = ImageLoader.loadImage("res/linedPaper.jpg").getSubimage(50,50,400,450);
        //EXAMPLE:////backgroundMusic = new File("backgroundMusic.wav");
    }

}
